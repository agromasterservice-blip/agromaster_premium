import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "START PRO SERVICE | Reparații în garanție",
  description: "Cereri de ridicare pentru reparații în garanție START PRO SERVICE"
};

export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ro">
      <body>{children}</body>
    </html>
  );
}

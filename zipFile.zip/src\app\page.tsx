import { RepairRequestForm } from "@/components/public/repair-request-form";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-paper">
      <section className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-5xl flex-col gap-4 px-4 py-8 sm:px-6 lg:px-8">
          <p className="text-sm font-semibold uppercase tracking-[0.12em] text-ocean">
            START PRO SERVICE
          </p>
          <div className="max-w-3xl">
            <h1 className="text-3xl font-bold tracking-normal text-slate-950 sm:text-4xl">
              Cerere de reparație în garanție
            </h1>
            <p className="mt-3 text-base leading-7 text-slate-600">
              Completați formularul pentru ridicarea produsului. Diagnosticarea este gratuită,
              iar transportul este achitat de START PRO SERVICE.
            </p>
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
        <RepairRequestForm />
      </div>
    </main>
  );
}

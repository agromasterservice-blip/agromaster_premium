import { WhatsappDemoChat } from "@/components/public/whatsapp-demo-chat";

export const metadata = {
  title: "WhatsApp demo | START PRO SERVICE"
};

export default function WhatsappDemoPage() {
  return <WhatsappDemoChat />;
}
